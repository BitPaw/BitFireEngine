#include "FLAC.h"

ActionResult FLACParse(const void* data, const size_t dataSize)
{
	return ResultInvalid;
}