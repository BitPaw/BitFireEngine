#include "WMA.h"

ActionResult WMAParse(WMA* wma, const void* data, const size_t dataSize, size_t* dataRead)
{
	return ResultInvalid;
}
