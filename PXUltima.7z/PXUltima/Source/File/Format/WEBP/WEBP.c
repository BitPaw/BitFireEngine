#include "WEBP.h"

ActionResult WEBPParse(WEBP* webp, const void* data, const size_t dataSize, size_t* dataRead)
{
    return ResultInvalid;
}
