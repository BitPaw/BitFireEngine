#pragma once

#ifndef MP4MInclude
#define MP4MInclude

#include <stddef.h>

#include <Error/ActionResult.h>

#ifdef __cplusplus
extern "C"
{
#endif
	typedef struct MP4_
	{
		unsigned int __dummy__;
	}
	MP4;

#ifdef __cplusplus
}
#endif

#endif