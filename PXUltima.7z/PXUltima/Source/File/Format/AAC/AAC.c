#include "AAC.h"

ActionResult AACParse(const void* data, const size_t dataSize)
{
	return ResultInvalid;
}