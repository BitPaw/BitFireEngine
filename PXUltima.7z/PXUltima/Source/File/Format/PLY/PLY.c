#include "PLY.h"

ActionResult PLYParse(PLY* ply, const void* data, const size_t dataSize, size_t* dataRead)
{
	return ResultInvalid;
}