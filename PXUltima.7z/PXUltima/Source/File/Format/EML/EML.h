#ifndef EMLInclude
#define EMLInclude

#ifdef __cplusplus
extern "C"
{
#endif

	typedef struct EML_
	{
		unsigned int __dummy__;
	}
	EML;

#ifdef __cplusplus
}
#endif

#endif