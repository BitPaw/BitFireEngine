#include "FBX.h"

ActionResult FBXParse(const void* data, const size_t dataSize)
{
	return ResultSuccessful;
}
