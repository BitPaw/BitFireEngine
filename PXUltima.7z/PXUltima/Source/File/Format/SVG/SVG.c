#include "SVG.h"

ActionResult SVGParse(SVG* svg, const void* data, const size_t dataSize, size_t* dataRead)
{
	return ResultInvalid;
}
