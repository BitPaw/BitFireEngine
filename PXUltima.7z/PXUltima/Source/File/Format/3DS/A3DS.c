#include "A3DS.h"

ActionResult A3DSParse(const void* data, const size_t dataSize)
{
	return ResultInvalid;
}
