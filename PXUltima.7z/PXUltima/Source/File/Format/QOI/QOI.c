#include "QOI.h"

ActionResult QOIParse(QOI* qoi, const void* data, const size_t dataSize, size_t* dataRead)
{
    return ResultInvalid;
}
