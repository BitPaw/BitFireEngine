#ifndef WebMInclude
#define WebMInclude

#include <stddef.h>

#include <Error/ActionResult.h>

#ifdef __cplusplus
extern "C"
{
#endif
	typedef struct WebM_
	{
		unsigned int __dummy__;
	}
	WebM;

#ifdef __cplusplus
}
#endif

#endif