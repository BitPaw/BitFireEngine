#include "VRML.h"

ActionResult VRMLParse(const void* data, const size_t dataSize)
{
	return ResultInvalid;
}