#include "STL.h"

ActionResult STLParse(const void* data, const size_t dataSize)
{
	return ResultInvalid;
}