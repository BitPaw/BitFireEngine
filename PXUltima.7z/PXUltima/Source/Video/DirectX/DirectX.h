#ifndef DirectXInclude
#define DirectXInclude

#ifdef __cplusplus
extern "C"
{
#endif
#pragma once

	typedef struct DirectX_
	{
		unsigned int __dummy__;
	}
	DirectX;

#ifdef __cplusplus
}
#endif

#endif