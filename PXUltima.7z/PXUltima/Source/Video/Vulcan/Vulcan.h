#ifndef VulcanInclude
#define VulcanInclude

#ifdef __cplusplus
extern "C"
{
#endif
#pragma once

	typedef struct Vulcan_
	{
		unsigned int __dummy__;
	}
	Vulcan;

#ifdef __cplusplus
}
#endif

#endif