#include "ISBN.h"

unsigned char ISBNIsValid(const void* data, const size_t dataSize)
{
    // Splitt

   // Zahlen 
   // 10 * []

   // 1 * x;

    return 0;
}